package com.mashibing.shardingsphere;

import com.mashibing.shardingsphere.bean.Customer;
import com.mashibing.shardingsphere.bean.DictOrderType;
import com.mashibing.shardingsphere.bean.Orders;
import com.mashibing.shardingsphere.bean.OrdersDetail;
import com.mashibing.shardingsphere.mapper.CustomerMapper;
import com.mashibing.shardingsphere.mapper.DictOrderTypeMapper;
import com.mashibing.shardingsphere.mapper.OrdersDetailMapper;
import com.mashibing.shardingsphere.mapper.OrdersMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Random;

@SpringBootTest
class ShardingsphereApplicationTests {

    @Autowired
    private OrdersMapper ordersMapper;

    @Test
    public void testInsert(){
        for (int i = 1; i <=10 ; i++) {
            Orders orders = new Orders();
            orders.setId(i);
            orders.setCustomerId(new Random().nextInt(10));
            orders.setOrderType(i);
            orders.setAmount(1000.0*i);
            ordersMapper.insertOrders(orders);
        }
    }

    @Test
    public void testSelect(){
        Orders select = ordersMapper.select(1);
        System.out.println(select);
    }

    @Autowired
    private CustomerMapper customerMapper;

    @Test
    public void insertCustomer(){
        for (int i = 1; i <= 10 ; i++) {
            Customer customer = new Customer();
            customer.setId(i);
            customer.setName("zs"+i);
            customerMapper.insertCustomer(customer);
        }
    }

    @Autowired
    private DictOrderTypeMapper dictOrderTypeMapper;

    @Test
    public void insertDictOrderType(){
        for (int i = 1; i <= 10 ; i++) {
            DictOrderType dictOrderType = new DictOrderType();
            dictOrderType.setOrderType("orderType"+i);
            dictOrderTypeMapper.insertDictOrderType(dictOrderType);
        }
    }

    @Test
    public void deleteDictOrderType(){
        dictOrderTypeMapper.DeleteDictOrderType(1);
    }

    @Autowired
    private OrdersDetailMapper ordersDetailMapper;
    @Test
    public void insertOrders_detail(){
        for (int i = 1; i <= 10 ; i++) {
            OrdersDetail ordersDetail = new OrdersDetail();
//            ordersDetail.setId(i);
            ordersDetail.setDetail("detail_"+i);
            ordersDetail.setOrder_id(i);
            ordersDetailMapper.insertOrdersDetail(ordersDetail);
        }
    }
}
