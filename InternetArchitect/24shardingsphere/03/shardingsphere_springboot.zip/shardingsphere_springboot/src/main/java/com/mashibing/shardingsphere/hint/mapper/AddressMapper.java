package com.mashibing.shardingsphere.hint.mapper;

import com.mashibing.shardingsphere.hint.bean.Address;

public interface AddressMapper extends CommonMapper<Address,Long> {

}