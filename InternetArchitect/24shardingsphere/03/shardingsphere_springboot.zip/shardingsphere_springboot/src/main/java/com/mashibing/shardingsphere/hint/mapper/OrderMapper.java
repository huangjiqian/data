package com.mashibing.shardingsphere.hint.mapper;

import com.mashibing.shardingsphere.hint.bean.Order;

public interface OrderMapper extends CommonMapper<Order,Long>{
}