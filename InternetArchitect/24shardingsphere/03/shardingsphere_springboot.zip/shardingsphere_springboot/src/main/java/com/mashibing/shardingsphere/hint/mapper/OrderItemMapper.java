package com.mashibing.shardingsphere.hint.mapper;

import com.mashibing.shardingsphere.hint.bean.OrderItem;

public interface OrderItemMapper extends CommonMapper<OrderItem,Long> {

}