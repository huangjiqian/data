package com.mashibing.shardingsphere.hint;

public enum HintType {
    
    DATABASE_ONLY, DATABASE_TABLES, MASTER_ONLY
}
