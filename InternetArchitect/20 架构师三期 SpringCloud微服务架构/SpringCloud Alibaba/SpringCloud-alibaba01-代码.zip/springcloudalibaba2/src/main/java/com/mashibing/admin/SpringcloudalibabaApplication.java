package com.mashibing.admin;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.alibaba.csp.sentinel.slots.block.RuleConstant;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRule;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRuleManager;

@SpringBootApplication
public class SpringcloudalibabaApplication {

	public static void main(String[] args) {
		
		// 不会被注册到 dashboard上
	//	initFlowRules();
		SpringApplication.run(SpringcloudalibabaApplication.class, args);
	}
	
	
	/**
	 * 服务 、方法的限流规则
	 */
	private static void initFlowRules() {
		List<FlowRule> rules = new ArrayList<>();
		
		FlowRule rule = new FlowRule();
		rule.setResource("HelloWorld");
		rule.setGrade(RuleConstant.FLOW_GRADE_QPS);
		// Set limit QPS to 20.
		rule.setCount(1);
		rules.add(rule);
		
		
		FlowRuleManager.loadRules(rules);
	}

}
