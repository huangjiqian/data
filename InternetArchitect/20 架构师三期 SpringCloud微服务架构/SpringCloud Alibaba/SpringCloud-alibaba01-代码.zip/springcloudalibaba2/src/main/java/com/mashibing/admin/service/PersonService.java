package com.mashibing.admin.service;

import org.springframework.stereotype.Service;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;

@Service
public class PersonService {

	@SentinelResource(value = "xxoo1",blockHandler = "back")
	public String getBody() {
		// 真正的业务逻辑
		// 被保护的资源
		return "给你我的肉体";
	}
	
	public String back(BlockException e) {
		
		return "降级了....";
	}

}
